﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class Supervisor : Empleado
    {
        private static float valorHora;

        public Supervisor()
        {
            valorHora = 1025.5F;
        }
        private Supervisor(string leg)
        {
            valorHora = 1025.5F;
            this.legajo = leg;
            this.nombre = "n/a";
            this.horaIngreso = new TimeSpan(09, 00, 00);

        }
        public double ValorHora
        {
            get { return valorHora; }
        }

        public void SetValorHora(double vHora)
        {
            if (vHora > 0)
            {

                valorHora = (float)vHora;

            }

        }
        public string EmitirFactura()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Factura de: {this.nombre}\nImporte a facturar: {this.Facturar()}");
            return stringBuilder.ToString();
        }
        private double CalculaBonoDeGrupo()
        {
            return 0.1;
        }
        protected new double Facturar()
        {

            double monto = (1 + CalculaBonoDeGrupo()) * (this.Facturar() * valorHora);

            return monto;
        }
    }
}
