﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class RAC : Empleado
    {
        private Egrupo grupo;
        // si lo hago estatico no funciona
        private static  double valorHora;


        public enum Egrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }
        private RAC(string nombre, string legajo, Egrupo grupo) 
        {
            this.nombre = nombre;
            this.legajo = legajo;
            this.grupo = grupo;
            SetValorHora(875.90F); 
        }
        public Egrupo Grupo
        {
            get
            {
                return grupo;
            }
        }
        public double ValorHora
        {
            get { return valorHora; }
        }
        public void SetValorHora(double vHora) 
        { if (vHora > 0 )
            {

                valorHora = vHora;

            }
                    
        }

        public string EmitirFactura()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Factura de: {this.nombre}\nImporte a facturar: {this.Facturar()}");
            return stringBuilder.ToString();
        }
        private double CalculaBonoDeGrupo()
        {
            return 0.1;
        }
        protected new double Facturar()
        {

            double monto = (1 + CalculaBonoDeGrupo()) * (this.Facturar() * valorHora);

            return monto;
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"{this.GetType().Name}-{this.legajo}-{this.nombre}");
            return stringBuilder.ToString();
        }
    }
}
