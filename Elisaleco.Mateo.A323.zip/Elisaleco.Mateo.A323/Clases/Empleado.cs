﻿namespace Clases
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        protected  TimeSpan HoraIngreso 
        { 
            get
            {
                return horaIngreso;
            } 
        }
        protected  TimeSpan HoraEgreso
        {
            get
            {
                return horaEgreso;
            }
        }
        protected void SetHoraEgreso(TimeSpan hora)
        {
            if (ValidaHoraEgreso(horaEgreso) == horaEgreso)
            {
                horaEgreso = hora;
            }

        }
        private TimeSpan ValidaHoraEgreso (TimeSpan hora) 
        {
            if (hora > this.HoraIngreso)
            {
                return hora;
            }
            else return DateTime.Now.TimeOfDay;
        }

        protected double Facturar()
        {

            TimeSpan horasTrabajadas = this.horaEgreso - this.HoraIngreso;

            return  horasTrabajadas.Hours;

        }

        public static bool operator == (Empleado a, Empleado b)
        {
            if (a.legajo == b.legajo)
            {
                return true;
            }
            return false;

        }
        public static bool operator !=(Empleado a, Empleado b)
        {
            if (!(a.legajo == b.legajo))
            {
                return true;
            }
            return false;

        }
    }
}